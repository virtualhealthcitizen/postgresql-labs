create view best_grades_with_names(id, student_name, subject, grade) as
SELECT r.id,
       r.student_name,
       r.subject,
       r.grade
FROM exam_grade_record r
         JOIN best_grades bg ON r.subject::text = bg.subject::text AND r.grade = bg.max_grade
ORDER BY r.subject;

alter table best_grades_with_names
    owner to admin;

