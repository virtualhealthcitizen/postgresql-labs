create view best_grades(max_grade, subject) as
SELECT max(grade) AS max_grade,
       subject
FROM exam_grade_record
GROUP BY subject;

alter table best_grades
    owner to admin;

